<!-- footer -->
            <footer class="padding-40px-tb bg-blue">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="text-small text-white xs-text-center xs-margin-15px-bottom">© 2019 Smyrna Brasil</a></div>
                        </div>
                        <div class="col-sm-5 no-padding">
                            
                        </div>
                        <div class="col-sm-3">
                            <div class="footer-social text-right xs-text-center xs-margin-10px-top">
                                <a href="#." class="facebook-text-hvr"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#." class="instagram-text-hvr"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- footer end-->